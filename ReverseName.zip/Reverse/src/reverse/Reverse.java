
package reverse;
import java.util.Scanner;
public class Reverse {

 
    public static void main(String[] args) {
        
            Scanner lastinpt = new Scanner(System.in);
            
        
             
            System.out.print("What's your name: ");
            String name = lastinpt.nextLine(); // .next 
            int nameLength = name.length();
            
            String answer = "";
            
            while (nameLength > 0){
            answer += name.substring(nameLength - 1, nameLength); 
            nameLength -= 1;
            }
           System.out.println("Your name in reverse is: " + answer.toLowerCase());
           
          
                           
    }
    
}
