﻿Public Class Form1
    Private Function f(x As Decimal) As Decimal
        Dim y As Decimal
        y = 2 ^ x - x - 2
        ' soltutions x=2, x= -1.69
        Return y

    End Function

    Private Function round(x As Decimal) As Decimal
        x = x * (1000) ' multiplies
        x = CInt(x) ' turns to int
        x = x / 1000 ' divides since Vs. Rounds
        Return x

    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If (IsNumeric(TextBox1.Text) Or (IsNumeric(TextBox2.Text) Or (IsNumeric(TextBox3.Text)))) = False Then
            MsgBox("ERROR - Not all of the values are numeric",, "ERROR")
            Exit Sub
        End If

        If (TextBox3.Text > 0 Or TextBox3.Text = CInt(TextBox3.Text Or IsNumeric(TextBox3.Text))) = False Then
            MsgBox("ERROR - 'N' must be a positive whole number",, "ERROR")
            Exit Sub
        End If

        If ((TextBox2.Text = TextBox1.Text)) Then
            MsgBox(TextBox1.Text + " and " + TextBox2.Text + " can't be equal",, "ERROR")
            Exit Sub
        End If


        ' main body

        Dim a As Decimal = TextBox1.Text
        Dim b As Decimal = TextBox2.Text
        Dim n As Integer = TextBox3.Text ' max
        Dim Mid As Decimal
        Dim Temp As Decimal = 1

        If (f(a) = 0) Then
            MsgBox(CStr(a) + " is the answer.",, "SOLUTION FOUND")
            Exit Sub
        End If

        If (f(b) = 0) Then
            MsgBox(CStr(b) + " is the answer.",, "SOLUTION FOUND")
            Exit Sub
        End If



        While (Temp < n) ' Limit
            Mid = (a + b) / 2 ' finds midpoint


            If f(Mid) = 0 Then
                ' might not need the second f(mid)
                ' Solution found
                MsgBox("The solution is rounded to " + CStr(round(Mid)),, "ANSWER:")
                Exit Sub
            End If

            Temp = Temp + 1 ' continues adding

            If ((f(Mid) > 0 And f(a) > 0) Or (f(Mid) < 0 And f(a) < 0)) Then
                a = Mid
            Else ' Starts a new interval
                b = Mid
            End If

        End While


    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub


End Class
