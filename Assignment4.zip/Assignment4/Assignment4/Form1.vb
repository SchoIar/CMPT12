﻿Public Class Principal
    Private Sub Calculate_Click(sender As Object, e As EventArgs) Handles Calculate.Click
        Dim Angle As String = TextBox1.Text
        If (Angle = "") Then
            MsgBox("Please Input a number",, "Results")
        Else

            If IsNumeric(TextBox1.Text) Then
                Dim A As Decimal = Angle
                'While (0 > A >= 360)
                While (0 > A)
                    A = A + 360
                End While

                While (A >= 360)
                    A = A - 360
                End While
                If (0 <= A < 360) Then
                    MsgBox("The principal angle is " + CStr(A),, "Results!")
                Else
                    MsgBox("Something went wrong")
                End If

            Else
                MsgBox(Angle + " isn't a number",, "Results")

            End If
        End If
    End Sub
End Class
