﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Dim Message As String
        Dim MessageLC As String
        Dim Name = TextBox1.Text
        ' Message = TextBox1.Text
        MessageLC = Name.ToLower

        Beep()
        If (MessageLC = "anton" And TextBox2.Text = "passWord") Then
            MsgBox("Entering Mainframe",, "Hello User.")
            Application.Exit()
        Else
            MsgBox("Your Username or password is incorrect",, "ERROR")
        End If


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

        Dim Name As String = TextBox1.Text


    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If (CheckBox1.Checked = True) Then
            TextBox2.UseSystemPasswordChar = False
        Else
            TextBox2.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub
End Class
