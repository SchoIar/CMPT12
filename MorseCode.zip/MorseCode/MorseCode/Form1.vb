﻿Public Class Form1

    Private Function Convert(aChar As String) As String
        Dim mCode As String

        aChar = UCase(aChar)

        If (aChar = "A") Then
            mCode = ".-"
        ElseIf (aChar = "B") Then
            mCode = "-..."
        ElseIf (aChar = "C") Then
            mCode = "-.-."
        ElseIf (aChar = "D") Then
            mCode = "-.."
        ElseIf (aChar = "E") Then
            mCode = "."
        ElseIf (aChar = "F") Then
            mCode = "..-."
        ElseIf (aChar = "G") Then
            mCode = "--."
        ElseIf (aChar = "H") Then
            mCode = "...."
        ElseIf (aChar = "I") Then
            mCode = ".."
        ElseIf (aChar = "J") Then
            mCode = ".---"
        ElseIf (aChar = "K") Then
            mCode = "-.-"
        ElseIf (aChar = "L") Then
            mCode = ".-.."
        ElseIf (aChar = "M") Then
            mCode = "--"
        ElseIf (aChar = "N") Then
            mCode = "-."
        ElseIf (aChar = "O") Then
            mCode = "---"
        ElseIf (aChar = "P") Then
            mCode = ".--."
        ElseIf (aChar = "Q") Then
            mCode = "--.-"
        ElseIf (aChar = "R") Then
            mCode = ".-."
        ElseIf (aChar = "S") Then
            mCode = "..."
        ElseIf (aChar = "T") Then
            mCode = "-"
        ElseIf (aChar = "U") Then
            mCode = "..-"
        ElseIf (aChar = "V") Then
            mCode = "...-"
        ElseIf (aChar = "W") Then
            mCode = ".--"
        ElseIf (aChar = "X") Then
            mCode = "-..-"
        ElseIf (aChar = "Y") Then
            mCode = "-.--"
        ElseIf (aChar = "Z") Then
            mCode = "--.."
        Else
            mCode = "/"
        End If

        mCode = mCode + " "

        Return mCode

    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim time As UInteger = NumericUpDown1.Value
        Dim freq As UInteger = NumericUpDown2.Value

        For i As Integer = 0 To Len(TextBox2.Text) - 1
            If TextBox2.Text(i) = "." Then
                Console.Beep(freq, time)
            ElseIf TextBox2.Text(i) = "-" Then
                Console.Beep(freq, 3 * time)
            ElseIf TextBox2.Text(i) = "/" Then
                Console.Beep(24000, 6 * time)
            Else
                Console.Beep(24000, 2 * time)
            End If
            Console.Beep(24000, time)
        Next

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Dim TxtB As String = TextBox1.Text
        TextBox2.Text = ""
        For i As Integer = 0 To Len(TxtB) - 1

            If Not (TxtB = "") Then
                TextBox2.Text = TextBox2.Text + Convert(TxtB(i))
            End If
        Next
    End Sub
End Class
