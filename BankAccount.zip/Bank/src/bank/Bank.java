
package bank;
public class Bank {
    // Check if balence and amount is positive
    public Bank(double bal, String n){
        balance = bal;
        name = n;
    }
    
    public void deposit(double d){
        if (d >= 0){
            balance = balance + d;
        }
        else
        {
            System.out.println("ERROR: You can't depositive negative money. Transaction Canceled.");
        }
    }    
    public void withdraw(double wd){
        if (wd >= 0 && balance >= wd){
        balance = balance - wd;
        }
            else
        {
            System.out.println("Error: Invalid withdrawl amount. Transaction Canceled.");
        }  
    }
    public void prBal(){
    System.out.print(name + "'s account balance is " + balance);
        
    }
     private double balance;
    private String name;

    
}
