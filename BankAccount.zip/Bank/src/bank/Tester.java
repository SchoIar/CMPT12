
package bank;
import java.util.Scanner;

public class Tester {
    
    public static void main(String[] args) {
    Scanner kbInput = new Scanner(System.in);
    
    System.out.print("Input your name: ");
    String n = kbInput.nextLine();
    System.out.print("Input your current balance: ");
    double bal = kbInput.nextDouble();
    if (bal < 0){
        System.out.println("Balance reset to zero.");
        bal = 0;
    }
    
    Bank myAccount = new Bank(bal, n);
    
    //myAccount.deposit(505.22);
    
    System.out.println("Input the amount that you'd like to deposit:");
    double deposit2 = kbInput.nextDouble();
    myAccount.deposit(deposit2);        
    
    myAccount.prBal();
    
    System.out.println("\nInput  the amount that you'd like to withdraw: ");
    double withdraw2 = kbInput.nextDouble();                
    myAccount.withdraw(withdraw2);
            
    myAccount.prBal();
            
    
    }

   
}
