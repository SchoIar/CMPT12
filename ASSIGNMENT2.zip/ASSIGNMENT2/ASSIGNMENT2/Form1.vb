﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Num As String = TextBox1.Text

        If (IsNumeric(Num)) Then
            If (Num > 0) Then
                MsgBox(CStr(Num) + " is positive.",, "RESULTS")
            End If

            If (Num < 0) Then
                MsgBox(CStr(Num) + " is negative.",, "RESULTS")
            End If

            If (Num = 0) Then
                MsgBox(CStr(Num) + " isn't positive nor negative but is a number.",, "RESULTS")
            End If

        Else
            MsgBox(CStr(Num) + " isn't a number.",, "RESULTS")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

        Application.Exit()

    End Sub
End Class
