﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim NumberA As Integer = TextBox1.Text
        Dim NumberB As Integer = TextBox2.Text
        Dim T As Integer


        While (NumberB <> 0)
            T = NumberA Mod NumberB
            NumberA = NumberB
            NumberB = T

        End While

        MsgBox(NumberA,, "Results")


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class
